// ---------------------------------------------------------------------------
// PayLink (https://uglypay.devugly.workers.dev) — bKash / Nagad / Rocket / Upay
//
// IMPORTANT: I could only read the *description* of this gateway's docs page
// (uglypay.devugly.workers.dev/docs) — the actual "ওয়েবসাইট ইন্টিগ্রেশন কোড"
// and "/webhook হ্যান্ডলার কোড" snippets are rendered client-side by that
// page's JavaScript, which my fetch tool can't execute, so I don't have the
// literal request/response shape or the webhook signature scheme.
//
// From the docs page text I do know:
//   - You sign up and get a merchant API key.
//   - You call an endpoint to create an invoice; the response includes a
//     `payUrl` you redirect the customer to.
//   - Customer pays via bKash/Nagad/Rocket/Upay and submits a Transaction ID,
//     which is auto-verified by SMS matching.
//   - On confirmation, PayLink POSTs a *signed* webhook to your worker.
//   - Each Transaction ID can only confirm one invoice (idempotent).
//
// Everything below is written to that shape as a best-effort placeholder so
// the bot runs end-to-end today. PASTE the two real code blocks from the
// docs page and I'll drop in the exact field names / header name / signature
// check in one pass.
// ---------------------------------------------------------------------------

import type { Env } from "../env";

export interface CreateInvoiceResult {
  invoiceId: string;
  payUrl: string;
}

export async function createInvoice(
  env: Env,
  { userId, amount }: { userId: number; amount: number }
): Promise<CreateInvoiceResult> {
  if (!env.PAYLINK_API_BASE || !env.PAYLINK_API_KEY) {
    throw new Error(
      "PayLink not configured — set PAYLINK_API_BASE / PAYLINK_API_KEY, then confirm the request " +
        "shape in src/payment/paylink.ts against the real docs snippet."
    );
  }

  const merchantInvoiceId = `dep_${userId}_${Date.now()}`;

  // --- PLACEHOLDER request shape — replace once you paste the real snippet ---
  const res = await fetch(`${env.PAYLINK_API_BASE}/api/invoice`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.PAYLINK_API_KEY}`,
    },
    body: JSON.stringify({
      amount,
      merchant_invoice_id: merchantInvoiceId,
      redirect_url: `${env.MINI_APP_BASE_URL}/index.html?deposited=1`,
      webhook_url: `${env.MINI_APP_BASE_URL}/api/deposit/webhook`,
    }),
  });

  if (!res.ok) {
    throw new Error(`PayLink error: ${res.status} ${await res.text()}`);
  }
  const data: any = await res.json();
  return { invoiceId: merchantInvoiceId, payUrl: data.payUrl || data.pay_url };
  // ---------------------------------------------------------------------
}

export interface VerifiedWebhook {
  invoiceId: string;
  amount: number;
}

/**
 * Verifies a PayLink webhook call and returns the paid invoice, or null if
 * the signature/payload doesn't check out. MUST verify the signature against
 * PAYLINK_API_KEY before this is trusted anywhere near a wallet credit.
 */
export async function verifyWebhook(env: Env, request: Request): Promise<VerifiedWebhook | null> {
  // --- PLACEHOLDER signature check — replace with the real header/algorithm ---
  const signature = request.headers.get("X-PayLink-Signature") || request.headers.get("X-Signature");
  const rawBody = await request.text();

  if (signature) {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      enc.encode(env.PAYLINK_API_KEY),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const mac = new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(rawBody)));
    const computed = [...mac].map((b) => b.toString(16).padStart(2, "0")).join("");
    if (computed !== signature) return null;
  }

  let body: any;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return null;
  }

  if (body.status !== "paid" && body.status !== "COMPLETED") return null;
  const invoiceId = body.merchant_invoice_id || body.metadata?.invoice_id;
  if (!invoiceId) return null;

  return { invoiceId, amount: Number(body.amount) };
  // ---------------------------------------------------------------------
}
